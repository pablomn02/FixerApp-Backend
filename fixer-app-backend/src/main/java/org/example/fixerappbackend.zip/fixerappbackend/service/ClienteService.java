package org.example.fixerappbackend.service;

import org.example.fixerappbackend.dto.ClienteDTO;
import org.example.fixerappbackend.model.Cliente;

import java.util.List;

public interface ClienteService {
    List<Cliente> findAll();
    Cliente findById(Long id);
//    Cliente save(ClienteDTO dto);
//    Cliente update(ClienteDTO dto);
    void delete(Long id);
}
