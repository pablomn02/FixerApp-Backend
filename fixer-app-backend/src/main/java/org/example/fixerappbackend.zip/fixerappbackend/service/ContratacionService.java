package org.example.fixerappbackend.service;

import org.example.fixerappbackend.model.Contratacion;

import java.util.List;

public interface ContratacionService {
    List<Contratacion> findAll();

    Contratacion save(Contratacion contratacion);
}
