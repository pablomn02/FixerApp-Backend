package org.example.fixerappbackend.dto;

import java.util.Map;

public class ClienteDTO {
    private Long id;
    private String nombre;
    private String preferencias;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPreferencias() {
        return preferencias;
    }

    public void setPreferencias(String preferencias) {
        this.preferencias = preferencias;
    }

    // Getters y setters
}
