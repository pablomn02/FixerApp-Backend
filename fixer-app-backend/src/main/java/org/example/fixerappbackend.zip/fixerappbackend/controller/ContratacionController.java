package org.example.fixerappbackend.controller;

import org.example.fixerappbackend.dto.ContratacionDTO;
import org.example.fixerappbackend.model.Cliente;
import org.example.fixerappbackend.model.Contratacion;
import org.example.fixerappbackend.model.ProfesionalServicio;
import org.example.fixerappbackend.service.ClienteService;
import org.example.fixerappbackend.service.ContratacionService;
import org.example.fixerappbackend.service.ProfesionalServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/contrataciones")
public class ContratacionController {
    @Autowired
    private ContratacionService contratacionService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private ProfesionalServicioService profesionalServicioService;

    @GetMapping
    @CrossOrigin("*")
    public List<Contratacion> getAllContrataciones() {
        return contratacionService.findAll();
    }

    @PostMapping
    @CrossOrigin("*")
    public ResponseEntity<Contratacion> crearContratacion(@RequestBody ContratacionDTO dto) {
        Cliente cliente = clienteService.findById(dto.getIdUsuario());
        Optional<ProfesionalServicio> ps = profesionalServicioService.findById(dto.getIdProfesionalServicio());

        Contratacion c = new Contratacion();
        c.setCliente(cliente);
        c.setProfesionalServicio(ps);
        c.setFechaHora(dto.getFechaHora());
        c.setEstado(dto.getEstado());
        c.setDuracionEstimada(dto.getDuracionEstimada());
        c.setCostoTotal(dto.getCostoTotal());

        return new ResponseEntity<>(contratacionService.save(c), HttpStatus.CREATED);
    }
}
