package org.example.fixerappbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FixerAppBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FixerAppBackendApplication.class, args);
	}

}